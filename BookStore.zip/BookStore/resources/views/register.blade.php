@extends('Template')
@section('content')


<form action="" method="POST">
    @csrf
    <input type="text" name="name" placeholder="Enter your name"> <br>
    <input type="text" name="email" placeholder="Enter your email"> <br>
    <input type="password" name="password" placeholder="Enter your password"> <br>
    <input type="password" name="password_confirmation" placeholder="Confirmation Password"> <br>
    <button type="submit">Register</button>
</form>

@endsection