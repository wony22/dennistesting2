@extends('layouts.app')
@section('content')

<form action="" method="POST" enctype="multipart/form-data">
    @csrf
    <h3>Insert Genre Form</h3>
     <label for="name">Name</label> <input type="text" name="name" id="name"> <br>  <br>
    <input type="submit" value="insert">

</form>

<div class="container d-flex justify-content-center">
    <table class="table ">
        <thead>
          <tr>
            <th scope="col">Task Name</th>
            <th scope="col">Action</th>
          </tr>
        </thead>

        <tbody>
            @foreach ($genre as $genres)
            <tr>
                <td>{{$genres->genres}} </td>
                <td>
                    <form action="{{route('genredetail', ['id'=> $genres->id])}}" method="GET">
                        @csrf
                        <button type="submit" class="btn btn-secondary">
                         View Detail
                        </button>
                        </form>
                </td>

                <td>
                    <form action="" method="POST">
                        @method('DELETE')
                        @csrf
                        <button type="submit" class="btn btn-danger">
                          Delete
                        </button>
                        </form>
                </td>
            </tr>
        @endforeach

        </tbody>

      </table>
</div>


@endsection
