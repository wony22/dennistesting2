@extends('layouts.app')
@section('content')

<form action="{{route('updategenre', ['id'=> $genre->id])}}" method="POST" enctype="multipart/form-data">
    @csrf
    <h3>{{$genre->genres}} Genre Detail</h3>
     <label for="name">Name</label> <input type="text" name="name" id="name"> <br>  <br>
    <input type="submit" value="Update">

</form>


@endsection
