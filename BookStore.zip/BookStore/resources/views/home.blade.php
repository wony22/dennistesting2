@extends('layouts.app')
@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Hello ') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('Welcome to this BookStore!') }}
                </div>
            </div>
        </div>
    </div>
    <div class="d-block w-50 " >
        {{-- <div class="headers bg-warning text-center" style="width: 50rem">
        <h3 class="head">Book List</h3>
        </div> --}}
        <table style="margin-bottom: 1rem;width:75rem;margin-top: 20px">
            <thead>
                <td>Cover</td>
                <td>Title</td>
                <td >Author</td>
            </thead>
            @forelse ($books as $book)
                <tr class="bg-secondary bg-opacity-25">
                    <td style="width:33%"><img src="{{asset('storage/'.$book->file_path)}}" alt=""></td>
                    <td style="width:33%"><a href="<?php echo e(url("/bookdetail/{$book->id}")); ?>" style="text-decoration: none; color: black">{{$book->nama}}</a></td>
                    <td style="width:33%">{{$book->author}}</td>
                </tr>
                @empty
                <tr>
                    <td>No Data....</td>
                </tr>
            @endforelse

        </table>
        {{$books->links()}}
    </div>
</div>
@endsection
