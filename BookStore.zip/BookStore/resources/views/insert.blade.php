@extends('layouts.app')
@section('content')

<form action="" method="POST" enctype="multipart/form-data">
    @csrf
    <h3>Insert Book Form</h3>
     <label for="name">Nama</label> <input type="text" name="name" id="name"> <br>  <br>
     <label for="author">Author</label>  <input type="text" name="author" id="author"> <br> <br>
     <label for="synopsis">Synopsis</label> <input type="text" name="synopsis" id="synopsis"><br> <br>
     <label for="genre">Genre(s)</label> <input type="checkbox" name="genre" id="genre"><br> <br>
     <label for="price">Price</label> <input type="number" name="price" id="price"><br> <br>
     <label for="cover">Cover</label><input type="file" name="cover" id="cover"><br>
        <input type="submit" value="insert">

</form>

@endsection
