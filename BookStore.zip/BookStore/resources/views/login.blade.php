@extends('Template')
@section('content')


@auth
    Hi, {{Auth::user()->name}}
    
    <form action="/logout" method="POST">
    @csrf
    <input type="submit" value=Logout>
</form>
@else

<form action="/login" method="post">
    @csrf
    <input type="email" name="email" id="email" placeholder="email"  value="{{ 
     Cookie::get('bookstorecookie') != null ? Cookie::get('bookstorecookie') : '' }}">
    <input type="password" name="password" id="password" placeholder="password">
    <input type="checkbox" name="remember" id="remember">Remember Me
    <input type="submit" value="Login">
</form>
@endif
@endsection