@extends('layouts.app')
@section('content')
<form action="{{route('updateuser', ['id'=> $users->id])}}" method="POST" enctype="multipart/form-data">
    @csrf
    <h3>{{$users->name}}'s User Detail</h3>
     <label for="name">Name  </label> <input type="text" name="name" id="name"> <br>
     <label for="email">Email </label> <input type="text" name="email" id="email"> <br>  <br>
    <input type="submit" value="Update">

</form>


@endsection
