@extends('layouts.app')
@section('content')

<div class="d-block w-100">
    <h3 class="head"> {{$books->nama}} Book Detail</h3>
    <div class="d-flex align-content-start justify-content-start">
        <div >
            <img src="{{asset('storage/'.$books->file_path)}}" alt="">
        </div>
        <div >
            <p>Name: {{$books->nama}}</p>
            <p>Author: {{$books->author}}</p>
            <p>Synopsis: {{$books->synopsis}}</p>
            <p>Genre[s]: </p>
            <p>Price: IDR.{{$books->price}}</p>
        </div>
    </div>
</div>

@endsection
