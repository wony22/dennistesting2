<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookStoreController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



// Route::post('login', [BookStoreController::class, 'login']);
// // Route::post('logout', [BookStoreController::class, 'logout']);
// Route::post('admin', [BookStoreController::class, 'adminPage']);
// Route::get('/register', function () {
//     return view('register');
// });

// Route::post('register', [BookStoreController::class, 'Register']);
// Route::get('/home', function () {
//     return view('home');
// });

Route::get('/', function (){
    return view('auth.login');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\BookStoreController::class, 'home'])->name('home');
Route::post('/insert',[App\Http\Controllers\BookStoreController::class, 'insertbook']);
Route::get('/insert',[App\Http\Controllers\BookStoreController::class, 'createbook']);

Route::get('/changePassword',[App\Http\Controllers\HomeController::class, 'showchangepasswordget']);
Route::post('/changePassword',[App\Http\Controllers\HomeController::class, 'changePassword'])->name('changepassword');

Route::post('/addgenre',[App\Http\Controllers\BookStoreController::class, 'insertgenre']);
Route::get('/addgenre',[App\Http\Controllers\BookStoreController::class, 'creategenre'])->name('addgenre');

Route::post('/genredetail/{id}',[App\Http\Controllers\BookStoreController::class, 'update'])->name('genredetail');
Route::get('/genredetail/{id}',[App\Http\Controllers\BookStoreController::class, 'updategenre'])->name('updategenre');

Route::get('/bookdetail/{id}',[App\Http\Controllers\BookStoreController::class,'bookdetail']);

Route::get('/manageuser',[App\Http\Controllers\BookStoreController::class,'manageuser'])->name('manageuser');

Route::post('/manageuser/{id}',[App\Http\Controllers\BookStoreController::class, 'updateuserrr'])->name('userdetail');
Route::get('/manageuser/{id}',[App\Http\Controllers\BookStoreController::class, 'updateuser'])->name('updateuser');


